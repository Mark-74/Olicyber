const express = require('express')
const fs = require('fs').promises
const path = require('path')
require('express-async-errors')

const app = express()
const PORT = 3000

app.set('view engine', 'ejs');

app.get('/', async (req, res) => {
    const files = await fs.readdir(__dirname + '/nft')

    res.render('index', nfts = files)
})

app.get('/nft', async (req, res) => {
    const filename = req.query.id

    for (const char of filename) {
        if (char === '.') {
            return res.send('nope')
        }
    }

    const p = path.join(__dirname, 'nft/' + filename)

    try {
        const data = await fs.readFile(p)
        res.render('nft', { base64img: data.toString('base64') })
    } catch (e) {
        res.send('Not found', 404)
    }

})


app.listen(PORT, () => {
    console.log(`Example app listening on port ${PORT}`)
})

